def insertion_sort(array, draw):
    """
    Сортировка вставками.

    Как работает:
    - Смотрим на каждый элемент начиная со второго
    - "Вставляем" его на правильное место среди уже просмотренных
    - Для этого сдвигаем все большие элементы вправо, пока не найдём место
    - Левая часть всегда остаётся отсортированной
    """
    n = len(array)
    steps = 0
    sorted_indices = [0]  # первый элемент изначально "отсортирован"

    for i in range(1, n):
        key = array[i]   # элемент который будем вставлять
        j = i - 1        # начинаем сравнивать с предыдущим

        # Показываем какой элемент вставляем
        draw(array,
             comparing=[i],
             sorted_indices=sorted_indices,
             title="Сортировка вставками",
             step_count=steps)

        
        while j >= 0 and array[j] > key:
            steps += 1

            
            draw(array,
                 comparing=[j, j + 1],
                 sorted_indices=sorted_indices,
                 title="Сортировка вставками — сдвиг",
                 step_count=steps)

            array[j + 1] = array[j]  
            j -= 1

            
            draw(array,
                 comparing=[j + 1, j + 2] if j >= 0 else [j + 1],
                 sorted_indices=sorted_indices,
                 title="Сортировка вставками — сдвиг",
                 step_count=steps)

        steps += 1
        array[j + 1] = key  

        
        sorted_indices = list(range(i + 1))

        draw(array,
             comparing=[j + 1],
             sorted_indices=sorted_indices,
             title="Сортировка вставками",
             step_count=steps)

    
    draw(array,
         comparing=[],
         sorted_indices=list(range(n)),
         title="Сортировка вставками — готово!",
         step_count=steps)

    return steps