def selection_sort(array, draw):
    """
    Сортировка выбором.

    Как работает:
    - Делим массив на отсортированную (левую) и неотсортированную (правую) части
    - На каждом шаге ищем минимум в неотсортированной части
    - Ставим минимум на первую позицию неотсортированной части (меняем местами)
    - Граница сдвигается на один вправо
    """
    n = len(array)
    steps = 0
    sorted_indices = []

    for i in range(n - 1):
        min_idx = i  # предполагаем что минимум — первый элемент неотсортированной части

        # Ищем минимум в оставшейся части
        for j in range(i + 1, n):
            steps += 1

            # Подсвечиваем: текущий кандидат на минимум и элемент с которым сравниваем
            draw(array,
                 comparing=[min_idx, j],
                 sorted_indices=sorted_indices,
                 title="Сортировка выбором",
                 step_count=steps)

            if array[j] < array[min_idx]:
                min_idx = j  # нашли новый минимум

        # Меняем минимум с первым неотсортированным элементом
        if min_idx != i:
            array[i], array[min_idx] = array[min_idx], array[i]

            # Показываем перестановку
            draw(array,
                 comparing=[i, min_idx],
                 sorted_indices=sorted_indices,
                 title="Сортировка выбором — перестановка",
                 step_count=steps)

        # Элемент встал на своё место
        sorted_indices.append(i)

        draw(array,
             comparing=[],
             sorted_indices=sorted_indices,
             title="Сортировка выбором",
             step_count=steps)

    # Последний элемент тоже на месте
    sorted_indices.append(n - 1)
    draw(array,
         comparing=[],
         sorted_indices=sorted_indices,
         title="Сортировка выбором — готово!",
         step_count=steps)

    return steps