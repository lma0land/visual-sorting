def bubble_sort(array, draw):
    """
    Сортировка пузырьком.

    Как работает:
    - Проходим по массиву снова и снова
    - Сравниваем соседние элементы, меняем если левый > правого
    - После каждого прохода наибольший элемент "всплывает" в конец
    - Останавливаемся когда за целый проход не было ни одной перестановки
    """
    n = len(array)
    steps = 0
    sorted_indices = []

    for i in range(n - 1):
        swapped = False  # флаг: была ли перестановка на этом проходе

        for j in range(n - 1 - i):
            steps += 1

            
            draw(array,
                 comparing=[j, j + 1],
                 sorted_indices=sorted_indices,
                 title="Сортировка пузырьком",
                 step_count=steps)

            if array[j] > array[j + 1]:
                
                array[j], array[j + 1] = array[j + 1], array[j]
                swapped = True

                
                draw(array,
                     comparing=[j, j + 1],
                     sorted_indices=sorted_indices,
                     title="Сортировка пузырьком",
                     step_count=steps)

        
        sorted_indices.append(n - 1 - i)

        
        draw(array,
             comparing=[],
             sorted_indices=sorted_indices,
             title="Сортировка пузырьком",
             step_count=steps)

        
        if not swapped:
            break

    
    sorted_indices = list(range(n))
    draw(array,
         comparing=[],
         sorted_indices=sorted_indices,
         title="Сортировка пузырьком — готово!",
         step_count=steps)

    return steps